// Run with: node test/run-tests.js  (needs Node.js; no packages required)
const assert = require('assert');
const path = require('path');
const C = require(path.join(__dirname, '..', 'core.js'));
require(path.join(__dirname, '..', 'sample-data.js'));

const rows = C.toRecords(globalThis.SAMPLE_CSV);
const a = C.analyze(rows);
const t = C.totals(rows, {});
const f = C.audit(rows, { threshold: 50000 });

assert.strictEqual(rows.length, 52, 'record count');
assert.strictEqual(a.issues.length, 8, 'issue count');
assert.strictEqual(t.income, 807800, 'total income');
assert.strictEqual(t.expense, 794100, 'total expenses');
assert.strictEqual(t.net, 13700, 'net profit');
assert.strictEqual(f.length, 6, 'audit flags');
['Duplicate entry', 'Calculation mismatch', 'Missing value', 'Invalid amount', 'Invalid date', 'Invalid type', 'Negative amount']
  .forEach(k => assert.ok(a.byType[k], 'expected issue type: ' + k));
assert.strictEqual(C.parseAmount('₹1,250.50'), 1250.5);
assert.ok(isNaN(C.parseAmount('abc')));
assert.strictEqual(C.parseDate('2026-02-30'), null);
assert.ok(C.parseDate('15/08/2026'));
assert.strictEqual(C.parseCSV('a,"b,c",d\n1,2,3').length, 2);
assert.throws(() => C.toRecords('foo,bar\n1,2'), /Missing required column/);
// excluding duplicates lowers expenses by the duplicate rent row (20,000)
assert.strictEqual(C.totals(rows, { excludeDupes: true }).expense, 774100);
// no fraud wording anywhere in audit output
assert.ok(!/fraud/i.test(JSON.stringify(f.map(x => x.reasons))), 'audit must not label fraud');
console.log('All tests passed.');
