/* SmartAudit AI - UI layer. All processing happens in the browser. */
(function () {
  'use strict';
  const C = window.SmartCore;
  const $ = (s, el) => (el || document).querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------------- Settings (saved in this browser only; the API key is NEVER saved) ---------------- */
  const SETTINGS_KEY = 'smartaudit.settings.v1';
  const DEFAULTS = { currency: '₹', threshold: 50000, excludeDupes: false, model: 'claude-sonnet-5-5', aiConsent: false, aiSendSummary: false };
  function loadSettings() {
    try { return Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')); }
    catch (e) { return Object.assign({}, DEFAULTS); }
  }
  function saveSettings() {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (e) { /* storage may be blocked */ }
  }
  let settings = loadSettings();
  let aiKey = ''; // memory only

  /* ---------------- State ---------------- */
  const state = {
    rows: [], source: '', isSample: true, analysis: null, totals: null, flags: [],
    reviewed: new Set(), errFilter: 'all', chat: [], reportData: null,
    report: {
      income: [{ name: 'Product sales', amount: 150000 }, { name: 'Service income', amount: 60000 }],
      expenses: [{ name: 'Rent', amount: 25000 }, { name: 'Salaries', amount: 85000 }, { name: 'Utilities', amount: 6000 }, { name: 'Marketing', amount: 12000 }],
      assets: [{ name: 'Cash and bank', amount: 120000 }, { name: 'Inventory', amount: 80000 }, { name: 'Equipment', amount: 150000 }],
      liabilities: [{ name: 'Bank loan', amount: 100000 }, { name: 'Accounts payable', amount: 30000 }]
    }
  };

  function money(n) {
    const v = Number(n) || 0;
    return (v < 0 ? '-' : '') + settings.currency + Math.abs(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  }
  function refresh() {
    state.analysis = C.analyze(state.rows);
    state.totals = C.totals(state.rows, { excludeDupes: settings.excludeDupes });
    state.flags = C.audit(state.rows, { threshold: settings.threshold });
  }
  function loadSample() {
    state.rows = C.toRecords(window.SAMPLE_CSV);
    state.source = 'Built-in sample data (fictional)';
    state.isSample = true;
    state.reviewed.clear();
    refresh();
  }
  function toast(type, msg) {
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.setAttribute('role', type === 'error' ? 'alert' : 'status');
    el.textContent = msg;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), 6500);
  }
  function download(name, text, mime) {
    const blob = new Blob([text], { type: mime || 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  const csvCell = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';

  function ingest(text, name) {
    let records;
    try { records = C.toRecords(text); }
    catch (e) { toast('error', e.message); return false; }
    state.rows = records; state.source = name; state.isSample = false; state.reviewed.clear();
    refresh();
    const n = state.analysis.issues.length;
    toast(n ? 'warning' : 'success', 'Loaded ' + records.length + ' records from ' + name + '. ' + (n ? n + ' potential issue(s) found - see Error Detection.' : 'No problems found by the automatic checks.'));
    render();
    return true;
  }

  /* ---------------- Icons ---------------- */
  const ICON = {
    dashboard: '<path d="M3 3h8v8H3zM13 3h8v5h-8zM13 10h8v11h-8zM3 13h8v8H3z"/>',
    reports: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
    errors: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
    audit: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
    assistant: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    settings: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'
  };
  const svgIcon = k => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[k] + '</svg>';
  const VIEWS = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'reports', label: 'Financial Reports' },
    { id: 'errors', label: 'Error Detection' },
    { id: 'audit', label: 'Audit Assistant' },
    { id: 'assistant', label: 'Ask Assistant' },
    { id: 'settings', label: 'Settings' }
  ];

  /* ---------------- Charts ---------------- */
  function niceMax(max) {
    const p = Math.pow(10, Math.floor(Math.log10(max)));
    const n = max / p;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
  }
  function compact(n) { return n >= 1e6 ? +(n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? +(n / 1e3).toFixed(1) + 'K' : String(n); }
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function monthlyChart(byMonth) {
    const keys = Object.keys(byMonth).sort();
    if (!keys.length) return '<p class="muted">No records with valid dates to chart.</p>';
    const W = 640, H = 280, m = { l: 52, r: 10, t: 12, b: 34 };
    const iw = W - m.l - m.r, ih = H - m.t - m.b;
    const top = niceMax(Math.max(1, ...keys.map(k => Math.max(byMonth[k].income, byMonth[k].expense))));
    const gw = iw / keys.length, bw = Math.min(30, gw / 2.7);
    let s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Bar chart of income and expenses by month">';
    for (let i = 0; i <= 4; i++) {
      const y = m.t + ih - (ih * i / 4);
      s += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + y + '" y2="' + y + '" stroke="#d9e4f2"/>';
      s += '<text x="' + (m.l - 6) + '" y="' + (y + 4) + '" text-anchor="end">' + compact(top * i / 4) + '</text>';
    }
    keys.forEach((k, i) => {
      const cx = m.l + gw * i + gw / 2;
      const d = byMonth[k];
      const hi = ih * d.income / top, he = ih * d.expense / top;
      s += '<rect x="' + (cx - bw - 1) + '" y="' + (m.t + ih - hi) + '" width="' + bw + '" height="' + hi + '" rx="3" fill="#2f6fdc"><title>' + esc(MONTHS[+k.slice(5) - 1] + ' income: ' + money(d.income)) + '</title></rect>';
      s += '<rect x="' + (cx + 1) + '" y="' + (m.t + ih - he) + '" width="' + bw + '" height="' + he + '" rx="3" fill="#0b2447"><title>' + esc(MONTHS[+k.slice(5) - 1] + ' expenses: ' + money(d.expense)) + '</title></rect>';
      s += '<text x="' + cx + '" y="' + (H - 12) + '" text-anchor="middle">' + MONTHS[+k.slice(5) - 1] + ' ' + k.slice(2, 4) + '</text>';
    });
    s += '</svg><div class="legend"><span><i style="background:#2f6fdc"></i>Income</span><span><i style="background:#0b2447"></i>Expenses</span></div>';
    return s;
  }
  function categoryBars(obj) {
    const e = Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, 8);
    if (!e.length) return '<p class="muted">No expense records to show.</p>';
    const max = e[0][1];
    return '<div class="bars">' + e.map(([k, v]) =>
      '<div class="bar-row"><span class="lab" title="' + esc(k) + '">' + esc(k) + '</span><div class="bar-track"><div class="bar-fill" style="width:' + Math.max(2, v / max * 100) + '%"></div></div><span class="right">' + money(v) + '</span></div>').join('') + '</div>';
  }

  /* ---------------- Views ---------------- */
  function dashboardView() {
    const t = state.totals, a = state.analysis;
    const netCls = t.net > 0 ? 'good' : t.net < 0 ? 'bad' : '';
    const catRows = obj => Object.entries(obj).sort((x, y) => y[1] - x[1]).map(([k, v]) => '<tr><td>' + esc(k) + '</td><td class="num">' + money(v) + '</td></tr>').join('');
    const topIssues = a.issues.slice(0, 5).map(i => '<tr><td>Row ' + i.line + '</td><td><span class="chip ' + i.sev + '">' + esc(i.type) + '</span></td><td>' + esc(i.message) + '</td></tr>').join('');
    return '<div class="page-head"><div><h1>Dashboard</h1><p class="muted">Data source: ' + esc(state.source) + '</p></div>' +
      '<div class="actions"><button class="btn" data-action="upload">Upload CSV</button><button class="btn ghost" data-action="load-sample">Reset to sample data</button></div></div>' +
      (state.isSample ? '<div class="alert info"><strong>Sample data:</strong> you are looking at fictional demonstration records that include deliberate mistakes. Upload your own CSV to analyse your data.</div>' : '') +
      '<div class="kpis">' +
      '<div class="kpi"><div class="label">Total income</div><div class="value">' + money(t.income) + '</div><div class="sub">' + t.incomeCount + ' income records counted</div></div>' +
      '<div class="kpi"><div class="label">Total expenses</div><div class="value">' + money(t.expense) + '</div><div class="sub">' + t.expenseCount + ' expense records counted</div></div>' +
      '<div class="kpi ' + netCls + '"><div class="label">Net ' + (t.net < 0 ? 'loss' : 'profit') + '</div><div class="value">' + money(t.net) + '</div><div class="sub">Income minus expenses</div></div>' +
      '<div class="kpi"><div class="label">Records checked</div><div class="value">' + a.checked + '</div><div class="sub">' + t.skipped + ' left out of totals (see below)</div></div>' +
      '<div class="kpi ' + (a.issues.length ? 'warn' : 'good') + '"><div class="label">Potential errors detected</div><div class="value">' + a.issues.length + '</div><div class="sub">' + a.errors + ' errors, ' + a.warnings + ' warnings in ' + a.rowsWithIssues + ' rows</div></div>' +
      '<div class="kpi ' + (state.flags.length ? 'warn' : 'good') + '"><div class="label">Items for human review</div><div class="value">' + state.flags.length + '</div><div class="sub">From the Audit Assistant</div></div>' +
      '</div>' +
      '<div class="grid2"><div class="card"><h2>Income vs expenses by month</h2>' + monthlyChart(t.byMonth) + '</div>' +
      '<div class="card"><h2>Top expense categories</h2>' + categoryBars(t.expByCat) + '</div></div>' +
      '<div class="card"><h2>Latest findings</h2>' + (topIssues ? '<div class="table-wrap"><table><thead><tr><th>Row</th><th>Type</th><th>What we found</th></tr></thead><tbody>' + topIssues + '</tbody></table></div><p class="small muted" style="margin-top:.6rem">Showing up to 5 of ' + a.issues.length + '. <a href="#errors">Open Error Detection</a> for the full list.</p>' : '<p>No problems found by the automatic checks. This does not prove the records are error-free.</p>') + '</div>' +
      '<div class="card"><h2>How these numbers are calculated</h2>' +
      '<p class="small muted">Every figure can be checked by hand or in a spreadsheet using the same rules.</p>' +
      '<div class="formula">Total income = sum of "amount" for rows with type Income and a positive numeric amount (' + t.incomeCount + ' rows) = ' + money(t.income) + '</div>' +
      '<div class="formula">Total expenses = sum of "amount" for rows with type Expense and a positive numeric amount (' + t.expenseCount + ' rows) = ' + money(t.expense) + '</div>' +
      '<div class="formula">Net profit or loss = total income - total expenses = ' + money(t.income) + ' - ' + money(t.expense) + ' = ' + money(t.net) + '</div>' +
      '<p class="small">Rows left out of the totals (' + t.skipped + '): amount missing/invalid/zero/negative, type missing/unrecognised' + (settings.excludeDupes ? ', or an exact duplicate (excluded in Settings)' : '') + '. ' + (settings.excludeDupes ? '' : 'Exact duplicates are <strong>included</strong> but flagged - you can change this in Settings.') + '</p>' +
      '<details><summary>Show totals by category</summary><div class="grid2" style="margin-top:.6rem"><div class="table-wrap"><table><thead><tr><th>Income category</th><th class="num">Amount</th></tr></thead><tbody>' + (catRows(t.incByCat) || '<tr><td colspan="2" class="muted">None</td></tr>') + '</tbody></table></div><div class="table-wrap"><table><thead><tr><th>Expense category</th><th class="num">Amount</th></tr></thead><tbody>' + (catRows(t.expByCat) || '<tr><td colspan="2" class="muted">None</td></tr>') + '</tbody></table></div></div></details></div>';
  }

  function repSection(key, title) {
    const rows = state.report[key].map((r, i) =>
      '<div class="rrow"><input class="r-in" data-sec="' + key + '" data-i="' + i + '" data-f="name" value="' + esc(r.name) + '" placeholder="Item name" aria-label="' + title + ' item name">' +
      '<input class="r-in" type="number" min="0" step="0.01" data-sec="' + key + '" data-i="' + i + '" data-f="amount" value="' + esc(r.amount) + '" placeholder="Amount" aria-label="' + title + ' amount">' +
      '<button class="btn danger small" data-action="rm-row" data-sec="' + key + '" data-i="' + i + '" aria-label="Remove row">&times;</button></div>').join('');
    return '<div class="card"><h2>' + title + '</h2>' + rows + '<button class="btn ghost small" data-action="add-row" data-sec="' + key + '">+ Add row</button></div>';
  }
  function reportsView() {
    return '<div class="page-head"><div><h1>Financial Reports</h1><p class="muted">Enter your figures, then generate a simple income and expense summary.</p></div>' +
      '<div class="actions"><button class="btn ghost" data-action="fill-report">Fill income &amp; expenses from loaded records</button></div></div>' +
      '<div class="alert info"><strong>Rule-based report:</strong> totals and ratios are plain arithmetic on the numbers you enter. The written summary uses fixed rules, not AI. Amounts are in ' + esc(settings.currency) + '.</div>' +
      '<div id="repErrors"></div>' +
      '<div class="grid2">' + repSection('income', 'Income') + repSection('expenses', 'Expenses') + '</div>' +
      '<div class="grid2">' + repSection('assets', 'Assets') + repSection('liabilities', 'Liabilities') + '</div>' +
      '<div class="actions no-print" style="margin-bottom:1rem"><button class="btn" data-action="gen-report">Generate report</button></div>' +
      '<div id="reportOut">' + (state.reportData ? reportHTML(state.reportData) : '') + '</div>';
  }
  function sum(list) { return C.round2(list.reduce((s, r) => s + r.amount, 0)); }
  function reportHTML(d) {
    const ps = d.net > 0 ? 'profit' : d.net < 0 ? 'loss' : 'break-even result';
    const table = (title, list, total, label) => '<h3>' + title + '</h3><div class="table-wrap"><table><tbody>' +
      (list.length ? list.map(r => '<tr><td>' + esc(r.name) + '</td><td class="num">' + money(r.amount) + '</td></tr>').join('') : '<tr><td colspan="2" class="muted">No items entered</td></tr>') +
      '<tr class="total"><td>' + label + '</td><td class="num">' + money(total) + '</td></tr></tbody></table></div>';
    const lines = [];
    if (d.net > 0) lines.push('The business made a net profit of ' + money(d.net) + ' (income ' + money(d.income) + ' minus expenses ' + money(d.expense) + ').');
    else if (d.net < 0) lines.push('The business made a net loss of ' + money(-d.net) + ': expenses (' + money(d.expense) + ') were higher than income (' + money(d.income) + ').');
    else lines.push('Income and expenses are equal, so the result is break-even.');
    if (d.income > 0) lines.push('Profit margin is ' + (d.net / d.income * 100).toFixed(1) + '% of income; expenses use ' + (d.expense / d.income * 100).toFixed(1) + '% of income.');
    if (d.expenses.length && d.expense > 0) { const big = d.expenses.slice().sort((a, b) => b.amount - a.amount)[0]; lines.push('The largest expense item is "' + big.name + '" at ' + money(big.amount) + ' (' + (big.amount / d.expense * 100).toFixed(1) + '% of expenses).'); }
    if (d.assets > 0) lines.push('Liabilities are ' + (d.liabilities / d.assets * 100).toFixed(1) + '% of assets' + (d.liabilities > d.assets ? ', which means liabilities exceed assets - worth discussing with an accountant.' : '.'));
    lines.push('Equity (assets minus liabilities) is ' + money(d.assets - d.liabilities) + '.');
    return '<div class="report"><h2>Sample Financial Report</h2><p class="muted small">Generated ' + esc(new Date().toLocaleString()) + ' from manually entered figures. Prepared with SmartAudit AI (decision-support only - have a qualified accountant review it before relying on it).</p>' +
      table('Income', d.incomeList, d.income, 'Total income') + table('Expenses', d.expenseList, d.expense, 'Total expenses') +
      '<h3>Result</h3><div class="formula">Net ' + ps + ' = total income - total expenses = ' + money(d.income) + ' - ' + money(d.expense) + ' = ' + money(d.net) + '</div>' +
      '<h3>Financial position (simplified)</h3><div class="grid2"><div>' + table('Assets', d.assetList, d.assets, 'Total assets') + '</div><div>' + table('Liabilities', d.liabilityList, d.liabilities, 'Total liabilities') + '</div></div>' +
      '<div class="formula">Equity = total assets - total liabilities = ' + money(d.assets) + ' - ' + money(d.liabilities) + ' = ' + money(d.assets - d.liabilities) + '</div>' +
      '<h3>Plain-English summary <span class="chip info">rule-based, not AI</span></h3><ul>' + lines.map(l => '<li>' + esc(l) + '</li>').join('') + '</ul>' +
      '<div class="actions no-print"><button class="btn" data-action="print-report">Print / save as PDF</button></div></div>';
  }
  function generateReport() {
    const errs = [];
    const clean = (key, label) => state.report[key].filter(r => String(r.name).trim() !== '' || String(r.amount).trim() !== '').map((r, i) => {
      const amt = C.parseAmount(r.amount);
      if (!String(r.name).trim()) errs.push(label + ': an amount was entered without an item name.');
      if (isNaN(amt)) errs.push(label + ' "' + (r.name || 'unnamed') + '": amount is missing or not a number.');
      else if (amt < 0) errs.push(label + ' "' + (r.name || 'unnamed') + '": amount cannot be negative here.');
      return { name: String(r.name).trim(), amount: isNaN(amt) ? 0 : amt };
    });
    const incomeList = clean('income', 'Income'), expenseList = clean('expenses', 'Expenses'), assetList = clean('assets', 'Assets'), liabilityList = clean('liabilities', 'Liabilities');
    const box = $('#repErrors');
    if (errs.length) {
      box.innerHTML = '<div class="alert err" role="alert"><strong>Please fix these before generating the report:</strong><ul>' + errs.map(e => '<li>' + esc(e) + '</li>').join('') + '</ul></div>';
      $('#reportOut').innerHTML = ''; state.reportData = null;
      toast('error', errs.length + ' problem(s) in the entered figures.');
      return;
    }
    box.innerHTML = '';
    const d = { incomeList, expenseList, assetList, liabilityList, income: sum(incomeList), expense: sum(expenseList), assets: sum(assetList), liabilities: sum(liabilityList) };
    d.net = C.round2(d.income - d.expense);
    d.expenses = expenseList;
    state.reportData = d;
    $('#reportOut').innerHTML = reportHTML(d);
    toast('success', 'Report generated. Net ' + (d.net < 0 ? 'loss ' : 'profit ') + money(Math.abs(d.net)) + '.');
    $('#reportOut').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function errorsView() {
    const a = state.analysis;
    const filtered = a.issues.filter(i => state.errFilter === 'all' || i.sev === state.errFilter);
    const lineSev = {};
    a.issues.forEach(i => { lineSev[i.line] = (lineSev[i.line] === 'error' || i.sev === 'error') ? 'error' : 'warning'; });
    const issueRows = filtered.map(i => '<tr><td>Row ' + i.line + '</td><td><span class="chip ' + i.sev + '">' + i.sev + '</span></td><td>' + esc(i.type) + '</td><td>' + esc(i.message) + '</td><td>' + esc(i.fix) + '</td></tr>').join('');
    const shown = state.rows.slice(0, 200);
    const recRows = shown.map(r => '<tr class="' + (lineSev[r._line] ? 'has-' + lineSev[r._line] : '') + '"><td>' + r._line + '</td><td>' + esc(r.date) + '</td><td>' + esc(r.description) + '</td><td>' + esc(r.vendor) + '</td><td>' + esc(r.category) + '</td><td>' + esc(r.type) + '</td><td class="num">' + esc(r.quantity) + '</td><td class="num">' + esc(r.unit_price) + '</td><td class="num">' + esc(r.amount) + '</td><td>' + (lineSev[r._line] ? '<span class="chip ' + lineSev[r._line] + '">' + lineSev[r._line] + '</span>' : '<span class="chip ok">ok</span>') + '</td><td><button class="btn danger small" data-action="del-row" data-line="' + r._line + '" aria-label="Delete row ' + r._line + '">Delete</button></td></tr>').join('');
    return '<div class="page-head"><div><h1>Error Detection</h1><p class="muted">Data source: ' + esc(state.source) + '</p></div>' +
      '<div class="actions"><button class="btn" data-action="upload">Upload CSV</button><button class="btn ghost" data-action="load-sample">Load sample data</button><button class="btn ghost" data-action="download-sample">Download sample CSV</button></div></div>' +
      '<div class="alert info">These checks look for <strong>missing values, duplicate entries, invalid amounts/dates/types and calculation mismatches</strong>. They cannot find every mistake, so a clean result does not prove the books are correct.</div>' +
      '<div class="grid2"><div class="card"><h2>1. Upload a CSV file</h2><div class="drop" id="drop"><p>Drag a .csv file here or</p><button class="btn" data-action="upload">Choose CSV file</button></div>' +
      '<p class="small muted" style="margin-top:.6rem">Required columns: <code>date</code>, <code>type</code>, <code>amount</code>. Optional: <code>description</code>, <code>vendor</code>, <code>category</code>, <code>quantity</code>, <code>unit_price</code>. Dates as YYYY-MM-DD or DD/MM/YYYY. The file is read in your browser and is not uploaded anywhere.</p></div>' +
      '<div class="card"><h2>2. Or paste CSV text</h2><label for="pasteBox">CSV text (include the header row)</label><textarea id="pasteBox" placeholder="date,description,vendor,category,type,quantity,unit_price,amount&#10;2026-10-01,Sale,Shop A,Sales,Income,2,500,1000"></textarea><div style="margin-top:.6rem"><button class="btn" data-action="check-paste">Check pasted data</button></div></div></div>' +
      '<div class="card"><h2>3. Or add a record manually</h2><div class="form-grid">' +
      '<div><label for="m-date">Date</label><input id="m-date" type="date"></div>' +
      '<div><label for="m-desc">Description</label><input id="m-desc"></div>' +
      '<div><label for="m-vendor">Vendor / party</label><input id="m-vendor"></div>' +
      '<div><label for="m-cat">Category</label><input id="m-cat"></div>' +
      '<div><label for="m-type">Type</label><select id="m-type"><option>Expense</option><option>Income</option></select></div>' +
      '<div><label for="m-qty">Quantity (optional)</label><input id="m-qty"></div>' +
      '<div><label for="m-price">Unit price (optional)</label><input id="m-price"></div>' +
      '<div><label for="m-amt">Amount</label><input id="m-amt" inputmode="decimal"></div></div>' +
      '<button class="btn" data-action="add-record">Add record and check</button> <span class="small muted">Tip: leave something blank or mistype the amount to see how errors are explained.</span></div>' +
      '<div class="kpis"><div class="kpi"><div class="label">Records checked</div><div class="value">' + a.checked + '</div></div>' +
      '<div class="kpi ' + (a.errors ? 'bad' : 'good') + '"><div class="label">Errors</div><div class="value">' + a.errors + '</div></div>' +
      '<div class="kpi ' + (a.warnings ? 'warn' : 'good') + '"><div class="label">Warnings</div><div class="value">' + a.warnings + '</div></div></div>' +
      '<div class="card"><div class="page-head" style="margin-bottom:.5rem"><h2 style="margin:0">Issues found</h2><div class="actions"><div><label for="sevFilter" class="small" style="display:inline">Show </label><select id="sevFilter" style="width:auto;display:inline-block"><option value="all"' + (state.errFilter === 'all' ? ' selected' : '') + '>All</option><option value="error"' + (state.errFilter === 'error' ? ' selected' : '') + '>Errors only</option><option value="warning"' + (state.errFilter === 'warning' ? ' selected' : '') + '>Warnings only</option></select></div><button class="btn ghost small" data-action="download-issues">Download issues (CSV)</button></div></div>' +
      (issueRows ? '<div class="table-wrap"><table><thead><tr><th>Where</th><th>Level</th><th>Problem</th><th>What it means</th><th>Suggested fix</th></tr></thead><tbody>' + issueRows + '</tbody></table></div>' : '<div class="alert ok" style="margin:0">No issues to show for this filter.</div>') + '</div>' +
      '<div class="card"><h2>Records (' + state.rows.length + ')</h2><div class="table-wrap" style="max-height:420px"><table><thead><tr><th>Row</th><th>Date</th><th>Description</th><th>Vendor</th><th>Category</th><th>Type</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead><tbody>' + recRows + '</tbody></table></div>' +
      (state.rows.length > 200 ? '<p class="small muted">Showing the first 200 rows. All rows are checked.</p>' : '') + '</div>';
  }

  function auditView() {
    const f = state.flags;
    const open = f.filter(x => !state.reviewed.has(x.line)).length;
    const rows = f.map(x => '<tr class="' + (state.reviewed.has(x.line) ? 'reviewed' : '') + '"><td>Row ' + x.line + '</td><td>' + esc(x.row.date) + '</td><td>' + esc(x.row.description || '(no description)') + '<div class="small muted">' + esc(x.row.vendor) + '</div></td><td class="num">' + money(x.row._amount) + '</td>' +
      '<td>' + x.reasons.map(r => '<div style="margin-bottom:.4rem"><span class="chip warning">' + esc(r.type) + '</span><div class="small">' + esc(r.text) + '</div><div class="small muted">Next step: ' + esc(r.step) + '</div></div>').join('') + '</td>' +
      '<td><span class="chip ' + (x.priority === 'Review' ? 'info' : 'warning') + '">' + x.priority + '</span></td>' +
      '<td><label class="check small"><input type="checkbox" data-review="' + x.line + '"' + (state.reviewed.has(x.line) ? ' checked' : '') + '> Reviewed</label></td></tr>').join('');
    return '<div class="page-head"><div><h1>Audit Assistant</h1><p class="muted">Data source: ' + esc(state.source) + '</p></div><div class="actions"><button class="btn" data-action="upload">Upload CSV</button><button class="btn ghost" data-action="download-flags">Download review list (CSV)</button></div></div>' +
      '<div class="alert warn"><strong>Important:</strong> these are statistical prompts for a human to look at. A flagged transaction is <strong>not</strong> evidence of fraud or wrongdoing, and nothing here is labelled as fraud. Many flags have innocent explanations (a genuine large purchase, two real invoices, a coincidence).</div>' +
      '<div class="kpis"><div class="kpi"><div class="label">Transactions analysed</div><div class="value">' + state.rows.length + '</div></div><div class="kpi warn"><div class="label">Flagged for human review</div><div class="value">' + f.length + '</div></div><div class="kpi ' + (open ? 'warn' : 'good') + '"><div class="label">Still to review</div><div class="value">' + open + '</div></div></div>' +
      '<div class="card"><h2>Items that need a human to look</h2>' + (rows ? '<div class="table-wrap"><table><thead><tr><th>Where</th><th>Date</th><th>Transaction</th><th class="num">Amount</th><th>Why it was flagged</th><th>Priority</th><th>Status</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<div class="alert ok" style="margin:0">Nothing was flagged by the three checks. That does not mean the records are risk-free.</div>') + '</div>' +
      '<div class="card"><h2>What the three checks do</h2><ol><li><strong>Unexpected amount:</strong> for each category with at least 4 records, an amount is flagged if it is far above the category median (robust modified z-score above 3.5, or more than 3 times the median when amounts barely vary).</li><li><strong>Possible duplicate payment:</strong> same vendor and same amount on expense records no more than 7 days apart.</li><li><strong>Just below approval limit:</strong> expenses within 10% under the approval limit set in <a href="#settings">Settings</a> (currently ' + money(settings.threshold) + ').</li></ol><p class="small muted">Limits: the checks only see the columns in your file, cannot judge whether a transaction was authorised, and will miss problems that look statistically normal.</p></div>';
  }

  const GLOSSARY = [
    { k: ['debit', 'credit'], t: 'Debit and credit', a: 'Every transaction is recorded on two sides. Debits increase assets and expenses; credits increase liabilities, equity and income. In a correct set of books, total debits equal total credits.' },
    { k: ['double-entry', 'double entry'], t: 'Double-entry bookkeeping', a: 'Each transaction is recorded twice: once as a debit and once as a credit. For example, paying rent reduces cash (credit) and increases rent expense (debit). This makes mistakes easier to spot.' },
    { k: ['balance sheet'], t: 'Balance sheet', a: 'A snapshot of what the business owns (assets), owes (liabilities) and the owners\' share (equity) on one date. Assets = Liabilities + Equity.' },
    { k: ['income statement', 'profit and loss', 'p&l', 'profit & loss'], t: 'Income statement (profit and loss)', a: 'Shows income and expenses over a period. Income minus expenses gives net profit or loss.' },
    { k: ['gross profit', 'net profit', 'profit margin'], t: 'Gross profit, net profit and margin', a: 'Gross profit = sales minus the direct cost of what you sold. Net profit = all income minus all expenses. Profit margin = net profit divided by income, shown as a percentage.' },
    { k: ['asset'], t: 'Assets', a: 'Things the business owns that have value, such as cash, stock (inventory), equipment and money customers owe you.' },
    { k: ['liabilit'], t: 'Liabilities', a: 'Money the business owes, such as bank loans, unpaid supplier bills and taxes due.' },
    { k: ['equity', 'capital'], t: 'Equity', a: 'What is left for the owners after liabilities are subtracted from assets: Equity = Assets - Liabilities.' },
    { k: ['accrual', 'cash basis', 'cash accounting'], t: 'Accrual vs cash accounting', a: 'Cash accounting records money when it moves. Accrual accounting records income and expenses when they are earned or incurred, even if payment comes later.' },
    { k: ['depreciation'], t: 'Depreciation', a: 'Spreading the cost of a long-lasting asset (like a machine) over the years you use it, instead of treating it all as an expense in the year you buy it.' },
    { k: ['accounts payable', 'payable'], t: 'Accounts payable', a: 'Bills you have received but not yet paid to suppliers. It is a liability.' },
    { k: ['accounts receivable', 'receivable'], t: 'Accounts receivable', a: 'Money customers owe you for goods or services already delivered. It is an asset.' },
    { k: ['trial balance'], t: 'Trial balance', a: 'A list of all ledger account balances to check that total debits equal total credits. If they do not match, there is an error somewhere.' },
    { k: ['ledger', 'journal'], t: 'Journal and ledger', a: 'The journal is the first record of each transaction in date order. The ledger groups those entries by account (cash, rent, sales and so on).' },
    { k: ['reconcil'], t: 'Reconciliation', a: 'Comparing your records with another source, usually the bank statement, and explaining every difference.' },
    { k: ['audit'], t: 'Audit', a: 'An independent check of financial records to see whether they are fairly presented. Auditors use evidence and professional judgement; this tool only gives review prompts.' },
    { k: ['cash flow'], t: 'Cash flow', a: 'The movement of money in and out of the business. A business can show a profit and still run short of cash if customers pay late.' },
    { k: ['working capital'], t: 'Working capital', a: 'Short-term assets minus short-term liabilities. It shows whether you can pay near-term bills.' },
    { k: ['duplicate'], t: 'Fixing duplicate entries', a: 'Compare the rows with the invoice or bank statement. If it was paid or received once, delete the extra row. If it really happened twice, keep both and add a clear description (for example the invoice number).' },
    { k: ['missing'], t: 'Fixing missing values', a: 'Find the original invoice, receipt or bank line and fill in the blank field. If the information cannot be found, mark the entry for follow-up instead of guessing.' },
    { k: ['mismatch', 'calculation', 'quantity'], t: 'Fixing calculation mismatches', a: 'Recompute quantity x unit price and compare with the recorded total. Then check the invoice: either the quantity, the price or the total was typed wrongly.' },
    { k: ['invalid amount', 'not a number', 'negative'], t: 'Fixing invalid or negative amounts', a: 'Amounts should be plain numbers. Remove letters and symbols. A negative amount usually means a refund or reversal: record it as a positive amount with the opposite type, or correct the typing mistake.' },
    { k: ['invalid date', 'date'], t: 'Fixing invalid dates', a: 'Use YYYY-MM-DD or DD/MM/YYYY and make sure the date exists (there is no 30 February). Check the source document for the right date.' },
    { k: ['unusual', 'outlier', 'unexpected', 'flag'], t: 'Unusual transactions', a: 'An unusual transaction is one that differs from the normal pattern, for example a much larger amount. It deserves a look, but there is often an innocent reason. Ask for the invoice and approval before drawing any conclusion.' },
    { k: ['fraud'], t: 'Fraud', a: 'Fraud means deliberate deception, and it needs evidence and proper investigation. This tool never decides that something is fraud; it only highlights items that a person should review.' }
  ];
  function demoAnswer(q) {
    const s = q.toLowerCase();
    if (/(my data|my records|summary|current data|how many error)/.test(s)) {
      const a = state.analysis, t = state.totals;
      return 'About the data currently loaded (' + state.source + '): ' + a.checked + ' records checked, ' + a.errors + ' errors and ' + a.warnings + ' warnings found, ' + state.flags.length + ' items flagged for human review. Income ' + money(t.income) + ', expenses ' + money(t.expense) + ', net ' + money(t.net) + '. See Error Detection and Audit Assistant for details.';
    }
    const scored = GLOSSARY.map(g => ({ g, n: g.k.filter(k => s.includes(k)).length })).filter(x => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 2);
    if (!scored.length) return 'I could not match that question to my built-in glossary. In demo mode I can explain common terms (debit, credit, balance sheet, profit and loss, assets, liabilities, equity, depreciation, reconciliation, cash flow and more) and suggest fixes for duplicate, missing, mismatched or invalid entries. Connecting a real AI model in Settings would allow open-ended answers.';
    return scored.map(x => x.g.t + ': ' + x.g.a).join('\n\n');
  }
  const aiLive = () => settings.aiConsent && !!aiKey;
  async function askAI(q) {
    let content = q;
    if (settings.aiSendSummary) {
      const a = state.analysis, t = state.totals;
      content += '\n\nContext (aggregate numbers only, no individual records): ' + a.checked + ' records, ' + a.errors + ' errors, ' + a.warnings + ' warnings, income ' + t.income + ', expenses ' + t.expense + ', net ' + t.net + '. Issue types: ' + JSON.stringify(a.byType) + '.';
    }
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': aiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({
        model: settings.model, max_tokens: 700,
        system: 'You are an accounting explainer for beginners inside a student prototype. Use simple English and short paragraphs. You support decisions but do not replace a qualified accountant or auditor. Never state that a transaction is fraud; say it needs human review.',
        messages: [{ role: 'user', content }]
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error((data && data.error && data.error.message) || ('Request failed (' + res.status + ')'));
    return (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');
  }
  function chatHTML() {
    return state.chat.map(m => '<div class="msg ' + m.role + (m.live ? ' live' : '') + '">' + (m.role === 'bot' ? '<span class="tag">' + (m.live ? 'LIVE AI (your API key)' : 'DEMO MODE - built-in glossary, not AI') + '</span>' : '') + esc(m.text).replace(/\n/g, '<br>') + '</div>').join('') || '<p class="muted small">No questions yet. Try one of the examples below.</p>';
  }
  function assistantView() {
    const live = aiLive();
    return '<div class="page-head"><div><h1>Ask Assistant</h1><p class="muted">Explains accounting terms in easy English and suggests fixes for errors.</p></div><span class="chip ' + (live ? 'ok' : 'warning') + '">' + (live ? 'Live AI mode' : 'Demo mode') + '</span></div>' +
      (live ? '<div class="alert ok">Live AI is on. Your question' + (settings.aiSendSummary ? ' and aggregate totals' : '') + ' will be sent to the Anthropic API using your own key. Individual records are never sent.</div>' :
        '<div class="alert warn"><strong>Demo mode:</strong> no AI model is connected. Answers come from a built-in glossary and fixed rules, <strong>not from artificial intelligence</strong>. To connect a real model, see <a href="#settings">Settings</a>.</div>') +
      '<div class="card"><div class="chat" id="chat" aria-live="polite">' + chatHTML() + '</div>' +
      '<div class="chips">' + ['What is a balance sheet?', 'Explain debit and credit', 'How do I fix duplicate entries?', 'What does calculation mismatch mean?', 'Is an unusual transaction fraud?', 'Summary of my data'].map(c => '<button class="btn ghost small" data-action="chip" data-q="' + esc(c) + '">' + esc(c) + '</button>').join('') + '</div>' +
      '<label for="qBox">Your accounting question</label><div style="display:flex;gap:.5rem"><input id="qBox" placeholder="e.g. What is depreciation?" maxlength="500"><button class="btn" data-action="ask">Ask</button></div></div>' +
      '<p class="small muted">Answers are general guidance for learning. Check important decisions with a qualified accountant.</p>';
  }
  async function ask(q) {
    q = String(q || '').trim();
    if (!q) { toast('warning', 'Type a question first.'); return; }
    state.chat.push({ role: 'user', text: q });
    if (aiLive()) {
      state.chat.push({ role: 'bot', text: 'Thinking...', live: true });
      render();
      try { state.chat[state.chat.length - 1].text = await askAI(q); }
      catch (e) { state.chat.pop(); state.chat.push({ role: 'bot', text: 'The AI request failed (' + e.message + '). Showing the demo answer instead:\n\n' + demoAnswer(q) }); toast('error', 'AI request failed: ' + e.message); }
    } else state.chat.push({ role: 'bot', text: demoAnswer(q) });
    render();
    const c = $('#chat'); if (c) c.scrollTop = c.scrollHeight;
  }

  function settingsView() {
    const sel = v => settings.currency === v ? ' selected' : '';
    return '<div class="page-head"><div><h1>Settings</h1><p class="muted">Saved only in this browser.</p></div></div>' +
      '<div class="card"><h2>General</h2><div class="form-grid two"><div><label for="s-cur">Currency symbol</label><select id="s-cur"><option' + sel('₹') + '>₹</option><option' + sel('$') + '>$</option><option' + sel('€') + '>€</option><option' + sel('£') + '>£</option></select></div>' +
      '<div><label for="s-thr">Approval limit for the audit check</label><input id="s-thr" type="number" min="0" step="1" value="' + esc(settings.threshold) + '"></div></div>' +
      '<label class="check"><input type="checkbox" id="s-dup"' + (settings.excludeDupes ? ' checked' : '') + '> Leave exact duplicate rows out of the totals (they are always flagged either way)</label></div>' +
      '<div class="card"><h2>Optional: connect a real AI model</h2><p class="small">Default is <strong>Demo mode</strong>. To enable live answers in Ask Assistant you must tick the consent box and paste your own Anthropic API key. The key is kept in memory only: it is never saved and disappears when you refresh the page. Your uploaded records are never sent; only your typed question (and optionally aggregate totals) is.</p>' +
      '<label class="check" style="margin-bottom:.6rem"><input type="checkbox" id="s-consent"' + (settings.aiConsent ? ' checked' : '') + '> I consent to sending my typed questions to the Anthropic API</label>' +
      '<label class="check" style="margin-bottom:.6rem"><input type="checkbox" id="s-sum"' + (settings.aiSendSummary ? ' checked' : '') + '> Also send aggregate totals and issue counts (no individual records)</label>' +
      '<div class="form-grid two"><div><label for="s-key">API key (not saved)</label><input id="s-key" type="password" autocomplete="off" placeholder="' + (aiKey ? 'Key set for this session' : 'sk-ant-...') + '"></div><div><label for="s-model">Model</label><input id="s-model" value="' + esc(settings.model) + '"></div></div>' +
      '<p class="small muted">Note: calling an API directly from a browser exposes the key to anyone using this page. This is fine for a personal demo. For a real product, send requests through your own server (see README).</p></div>' +
      '<div class="actions"><button class="btn" data-action="save-settings">Save settings</button><button class="btn ghost" data-action="clear-key">Clear API key</button><button class="btn danger" data-action="reset-all">Reset everything</button></div>';
  }

  /* ---------------- Rendering ---------------- */
  const fns = { dashboard: dashboardView, reports: reportsView, errors: errorsView, audit: auditView, assistant: assistantView, settings: settingsView };
  function renderNav(cur) {
    $('#nav').innerHTML = VIEWS.map(v => {
      const b = v.id === 'errors' && state.analysis && state.analysis.issues.length ? '<span class="badge">' + state.analysis.issues.length + '</span>' : v.id === 'audit' && state.flags.length ? '<span class="badge">' + state.flags.length + '</span>' : '';
      return '<a href="#' + v.id + '" class="' + (v.id === cur ? 'active' : '') + '"' + (v.id === cur ? ' aria-current="page"' : '') + '>' + svgIcon(v.id === 'dashboard' ? 'dashboard' : v.id) + v.label + b + '</a>';
    }).join('');
    const pill = $('#topMode');
    pill.textContent = aiLive() ? 'Live AI' : 'Demo mode';
    pill.className = 'mode-pill' + (aiLive() ? ' live' : '');
  }
  function render() {
    let id = location.hash.slice(1);
    if (!fns[id]) id = 'dashboard';
    const keepFocus = document.activeElement && document.activeElement.id;
    $('#view').innerHTML = fns[id]();
    renderNav(id);
    document.title = (VIEWS.find(v => v.id === id) || {}).label + ' - SmartAudit AI';
    document.body.classList.remove('menu-open');
    if (keepFocus && $('#' + keepFocus) && id === 'assistant') $('#' + keepFocus).focus();
    const c = $('#chat'); if (c) c.scrollTop = c.scrollHeight;
  }

  /* ---------------- Events ---------------- */
  function readRepSection(sec, i) { return state.report[sec][i]; }
  const actions = {
    'toggle-menu': () => document.body.classList.toggle('menu-open'),
    upload: () => { const f = $('#csvInput'); f.value = ''; f.click(); },
    'load-sample': () => { loadSample(); render(); toast('success', 'Sample data loaded. Found ' + state.analysis.issues.length + ' potential issues.'); },
    'download-sample': () => { download('smartaudit-sample.csv', window.SAMPLE_CSV); toast('info', 'Sample CSV downloaded. You can upload it back to test.'); },
    'check-paste': () => {
      const t = ($('#pasteBox') || {}).value || '';
      if (!t.trim()) { toast('warning', 'Paste some CSV text first.'); return; }
      ingest(t, 'pasted text');
    },
    'add-record': () => {
      const g = id => ($('#' + id).value || '').trim();
      const rec = { _line: Math.max(1, ...state.rows.map(r => r._line)) + 1, date: g('m-date'), description: g('m-desc'), vendor: g('m-vendor'), category: g('m-cat'), type: g('m-type'), quantity: g('m-qty'), unit_price: g('m-price'), amount: g('m-amt') };
      state.rows.push(rec);
      if (state.isSample) state.source += ' + manual entries'; else if (!/manual/.test(state.source)) state.source += ' + manual entries';
      state.isSample = false;
      refresh();
      const mine = state.analysis.issues.filter(i => i.line === rec._line);
      render();
      if (mine.length) toast(mine.some(i => i.sev === 'error') ? 'error' : 'warning', 'Record added as Row ' + rec._line + ' with ' + mine.length + ' issue(s): ' + mine.map(i => i.type).join(', ') + '.');
      else toast('success', 'Record added as Row ' + rec._line + '. No problems found.');
    },
    'del-row': t => {
      const line = +t.dataset.line;
      state.rows = state.rows.filter(r => r._line !== line);
      state.isSample = false; state.reviewed.delete(line);
      refresh(); render(); toast('info', 'Row ' + line + ' removed from the loaded data (your original file is unchanged).');
    },
    'download-issues': () => {
      const a = state.analysis;
      if (!a.issues.length) { toast('info', 'There are no issues to download.'); return; }
      download('smartaudit-issues.csv', ['row,level,problem,explanation,suggested_fix'].concat(a.issues.map(i => [i.line, i.sev, i.type, i.message, i.fix].map(csvCell).join(','))).join('\n'));
      toast('success', 'Issues downloaded.');
    },
    'download-flags': () => {
      if (!state.flags.length) { toast('info', 'There are no flagged items to download.'); return; }
      download('smartaudit-review-list.csv', ['row,date,description,vendor,amount,priority,reasons,reviewed'].concat(state.flags.map(f => [f.line, f.row.date, f.row.description, f.row.vendor, f.row._amount, f.priority, f.reasons.map(r => r.type + ': ' + r.text).join(' | '), state.reviewed.has(f.line) ? 'yes' : 'no'].map(csvCell).join(','))).join('\n'));
      toast('success', 'Review list downloaded.');
    },
    'add-row': t => { state.report[t.dataset.sec].push({ name: '', amount: '' }); state.reportData = null; render(); },
    'rm-row': t => { state.report[t.dataset.sec].splice(+t.dataset.i, 1); state.reportData = null; render(); },
    'fill-report': () => {
      const t = state.totals;
      const toList = o => Object.entries(o).sort((a, b) => b[1] - a[1]).map(([name, amount]) => ({ name, amount }));
      if (!t.incomeCount && !t.expenseCount) { toast('warning', 'No valid income or expense records are loaded.'); return; }
      state.report.income = toList(t.incByCat); state.report.expenses = toList(t.expByCat); state.reportData = null;
      render(); toast('success', 'Income and expenses filled from ' + (t.incomeCount + t.expenseCount) + ' loaded records. Enter assets and liabilities yourself.');
    },
    'gen-report': generateReport,
    'print-report': () => window.print(),
    chip: t => ask(t.dataset.q),
    ask: () => { const b = $('#qBox'); const q = b.value; b.value = ''; ask(q); },
    'save-settings': () => {
      const thr = Number($('#s-thr').value);
      if (!isFinite(thr) || thr < 0) { toast('error', 'The approval limit must be a number that is 0 or more.'); return; }
      const model = $('#s-model').value.trim();
      const key = $('#s-key').value.trim();
      const consent = $('#s-consent').checked;
      if (key) aiKey = key;
      if (aiKey && !consent) toast('warning', 'API key set, but consent is not ticked, so Demo mode stays on.');
      if (consent && !aiKey) toast('warning', 'Consent ticked but no API key entered yet, so Demo mode stays on.');
      if (!model) { toast('error', 'Please enter a model name.'); return; }
      settings = { currency: $('#s-cur').value, threshold: thr, excludeDupes: $('#s-dup').checked, model, aiConsent: consent, aiSendSummary: $('#s-sum').checked };
      saveSettings(); refresh(); render();
      toast('success', 'Settings saved. ' + (aiLive() ? 'Live AI mode is ON.' : 'Demo mode is active.'));
    },
    'clear-key': () => { aiKey = ''; render(); toast('info', 'API key cleared. Demo mode is active.'); },
    'reset-all': () => {
      if (!confirm('Reset settings, loaded data, report entries and chat to defaults?')) return;
      try { localStorage.removeItem(SETTINGS_KEY); } catch (e) { /* ignore */ }
      settings = Object.assign({}, DEFAULTS); aiKey = ''; state.chat = []; state.reportData = null;
      loadSample(); render(); toast('success', 'Everything was reset.');
    }
  };
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-action]');
    if (t && actions[t.dataset.action]) { e.preventDefault(); actions[t.dataset.action](t, e); }
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'sevFilter') { state.errFilter = e.target.value; render(); }
    else if (e.target.dataset && e.target.dataset.review) {
      const n = +e.target.dataset.review;
      if (e.target.checked) state.reviewed.add(n); else state.reviewed.delete(n);
      render();
    }
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.classList && t.classList.contains('r-in')) {
      readRepSection(t.dataset.sec, +t.dataset.i)[t.dataset.f] = t.value;
      if (state.reportData) { state.reportData = null; const o = $('#reportOut'); if (o) o.innerHTML = '<div class="alert info">Figures changed - click "Generate report" to refresh the report.</div>'; }
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.id === 'qBox') { e.preventDefault(); actions.ask(); }
  });
  document.addEventListener('dragover', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) { e.preventDefault(); d.classList.add('over'); } });
  document.addEventListener('dragleave', e => { const d = e.target.closest && e.target.closest('#drop'); if (d) d.classList.remove('over'); });
  document.addEventListener('drop', e => {
    const d = e.target.closest && e.target.closest('#drop');
    if (d) { e.preventDefault(); d.classList.remove('over'); if (e.dataTransfer.files[0]) readFile(e.dataTransfer.files[0]); }
  });
  function readFile(file) {
    if (!/\.csv$/i.test(file.name) && file.type !== 'text/csv') { toast('error', '"' + file.name + '" is not a CSV file. Please choose a .csv file (in Excel use Save As > CSV).'); return; }
    if (file.size > 5 * 1024 * 1024) { toast('error', 'That file is larger than 5 MB. Please upload a smaller file.'); return; }
    const fr = new FileReader();
    fr.onerror = () => toast('error', 'The file could not be read.');
    fr.onload = () => ingest(String(fr.result), file.name);
    fr.readAsText(file);
  }
  $('#csvInput').addEventListener('change', e => { if (e.target.files[0]) readFile(e.target.files[0]); });
  window.addEventListener('hashchange', render);

  /* ---------------- Start ---------------- */
  loadSample();
  render();
})();
