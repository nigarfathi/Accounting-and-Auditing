/* SmartAudit AI - core logic (no DOM). Works in the browser (window.SmartCore) and in Node (module.exports) for testing. */
(function (root) {
  'use strict';

  const COLS = ['date', 'description', 'vendor', 'category', 'type', 'quantity', 'unit_price', 'amount'];
  const ALIASES = {
    item: 'description', details: 'description', narration: 'description', particulars: 'description',
    party: 'vendor', supplier: 'vendor', customer: 'vendor', payee: 'vendor',
    account: 'category', head: 'category',
    qty: 'quantity', price: 'unit_price', unitprice: 'unit_price', rate: 'unit_price',
    value: 'amount', total: 'amount',
    debit_credit: 'type', transaction_type: 'type'
  };

  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
  function num(n) { return Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 }); }
  function median(a) {
    const s = [...a].sort((x, y) => x - y);
    const m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }

  /* ---------- CSV parsing (handles quotes, commas in quotes, CRLF) ---------- */
  function parseCSV(text) {
    const rows = [];
    let row = [], field = '', inQ = false;
    text = String(text).replace(/^﻿/, '');
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (inQ) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false;
        } else field += c;
      } else if (c === '"') inQ = true;
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(field); field = ''; rows.push(row); row = [];
      } else field += c;
    }
    if (field !== '' || row.length) { row.push(field); rows.push(row); }
    return rows.filter(r => r.some(x => x.trim() !== ''));
  }

  function toRecords(text) {
    const table = parseCSV(text);
    if (table.length < 2) throw new Error('The file has no data rows. It needs a header row and at least one record.');
    if (table.length - 1 > 20000) throw new Error('This prototype handles up to 20,000 rows. Please upload a smaller file.');
    const header = table[0].map(h => {
      const k = h.trim().toLowerCase().replace(/[\s\-\/]+/g, '_');
      return ALIASES[k] || k;
    });
    const missingCols = ['date', 'amount', 'type'].filter(c => !header.includes(c));
    if (missingCols.length) {
      throw new Error('Missing required column(s): ' + missingCols.join(', ') + '. Expected columns: ' + COLS.join(', ') + '.');
    }
    return table.slice(1).map((cells, i) => {
      const r = { _line: i + 2 };
      COLS.forEach(c => { r[c] = ''; });
      header.forEach((h, j) => { if (COLS.includes(h)) r[h] = String(cells[j] == null ? '' : cells[j]).trim(); });
      return r;
    });
  }

  /* ---------- Parsing helpers ---------- */
  function parseAmount(v) {
    if (v == null) return NaN;
    let s = String(v).trim();
    if (s === '') return NaN;
    s = s.replace(/[₹$€£,\s]|rs\.?|inr/gi, '');
    if (/^\(.*\)$/.test(s)) s = '-' + s.slice(1, -1);
    if (!/^-?\d+(\.\d+)?$/.test(s)) return NaN;
    return Number(s);
  }

  function parseDate(v) {
    const s = String(v == null ? '' : v).trim();
    let y, m, d, mt;
    if ((mt = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) { y = +mt[1]; m = +mt[2]; d = +mt[3]; }
    else if ((mt = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/))) { d = +mt[1]; m = +mt[2]; y = +mt[3]; }
    else return null;
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
    return dt;
  }

  function normType(v) {
    const s = String(v == null ? '' : v).trim().toLowerCase();
    if (/^(income|credit|revenue|sale|sales|receipt|cr)$/.test(s)) return 'Income';
    if (/^(expense|debit|cost|payment|purchase|dr)$/.test(s)) return 'Expense';
    return null;
  }

  /* ---------- Feature 2: error detection ---------- */
  function analyze(rows) {
    const issues = [];
    const seen = new Map();
    const add = (r, sev, type, message, fix) => issues.push({ line: r._line, sev, type, message, fix });
    rows.forEach(r => {
      r._amount = parseAmount(r.amount);
      r._date = parseDate(r.date);
      r._type = normType(r.type);
      r._dup = false;
      const blank = k => !String(r[k] == null ? '' : r[k]).trim();

      const missing = ['date', 'description', 'category', 'type', 'amount'].filter(blank);
      if (missing.length) add(r, 'error', 'Missing value', 'Missing: ' + missing.join(', ') + '.', 'Fill in the empty field(s) using the invoice, receipt or bank statement.');
      if (blank('vendor')) add(r, 'warning', 'Missing vendor', 'No vendor / party name is recorded.', 'Add who was paid or who paid you, so the entry can be traced later.');

      if (!blank('date') && !r._date) add(r, 'error', 'Invalid date', '"' + r.date + '" is not a real calendar date (use YYYY-MM-DD or DD/MM/YYYY).', 'Correct the date. Dates such as 30 February do not exist.');
      if (!blank('type') && !r._type) add(r, 'error', 'Invalid type', '"' + r.type + '" is not recognised. Use Income or Expense.', 'Change the type to Income or Expense. Refunds can be recorded as a separate row with the correct type.');

      if (!blank('amount')) {
        if (isNaN(r._amount)) add(r, 'error', 'Invalid amount', '"' + r.amount + '" is not a valid number.', 'Replace it with the correct numeric amount (digits only, e.g. 12500.50).');
        else if (r._amount < 0) add(r, 'warning', 'Negative amount', 'Amount is negative (' + num(r._amount) + '). Negative rows are left out of the totals.', 'If this is a refund or reversal, record it as a positive amount with the opposite type. If it is a typing mistake, correct it.');
        else if (r._amount === 0) add(r, 'warning', 'Zero amount', 'Amount is zero.', 'Check whether this entry is needed at all.');
      }

      const q = parseAmount(r.quantity), p = parseAmount(r.unit_price);
      if (!blank('quantity') && isNaN(q)) add(r, 'warning', 'Invalid quantity', '"' + r.quantity + '" is not a number.', 'Enter the quantity as a number.');
      if (!blank('unit_price') && isNaN(p)) add(r, 'warning', 'Invalid unit price', '"' + r.unit_price + '" is not a number.', 'Enter the unit price as a number.');
      if (!isNaN(q) && !isNaN(p) && !isNaN(r._amount)) {
        const exp = round2(q * p);
        if (Math.abs(exp - r._amount) > 0.01) {
          add(r, 'error', 'Calculation mismatch', 'Quantity ' + num(q) + ' x unit price ' + num(p) + ' = ' + num(exp) + ', but the recorded amount is ' + num(r._amount) + ' (difference ' + num(round2(r._amount - exp)) + ').', 'Compare quantity, price and total with the original invoice and fix whichever figure is wrong.');
        }
      }

      if (!isNaN(r._amount) && !blank('date')) {
        const key = [r.date.trim(), r.description.trim().toLowerCase(), r.vendor.trim().toLowerCase(), r._amount, r._type || ''].join('|');
        if (seen.has(key)) {
          r._dup = true;
          add(r, 'error', 'Duplicate entry', 'Looks identical to Row ' + seen.get(key) + ' (same date, description, vendor and amount). It would be counted twice.', 'If it is a genuine repeat, keep it. Otherwise delete the extra row.');
        } else seen.set(key, r._line);
      }
    });
    issues.sort((a, b) => a.line - b.line);
    const byType = {};
    issues.forEach(i => { byType[i.type] = (byType[i.type] || 0) + 1; });
    return {
      issues,
      checked: rows.length,
      rowsWithIssues: new Set(issues.map(i => i.line)).size,
      errors: issues.filter(i => i.sev === 'error').length,
      warnings: issues.filter(i => i.sev === 'warning').length,
      byType
    };
  }

  /* ---------- Feature 1 & 4: transparent totals ---------- */
  function totals(rows, opts) {
    opts = opts || {};
    const t = { income: 0, expense: 0, incomeCount: 0, expenseCount: 0, skipped: 0, byMonth: {}, expByCat: {}, incByCat: {} };
    rows.forEach(r => {
      if (!(r._amount > 0) || !r._type || (opts.excludeDupes && r._dup)) { t.skipped++; return; }
      const cat = String(r.category || '').trim() || 'Uncategorised';
      if (r._type === 'Income') { t.income += r._amount; t.incomeCount++; t.incByCat[cat] = (t.incByCat[cat] || 0) + r._amount; }
      else { t.expense += r._amount; t.expenseCount++; t.expByCat[cat] = (t.expByCat[cat] || 0) + r._amount; }
      if (r._date) {
        const k = r._date.toISOString().slice(0, 7);
        const m = t.byMonth[k] = t.byMonth[k] || { income: 0, expense: 0 };
        m[r._type === 'Income' ? 'income' : 'expense'] += r._amount;
      }
    });
    t.income = round2(t.income); t.expense = round2(t.expense); t.net = round2(t.income - t.expense);
    [t.expByCat, t.incByCat].forEach(o => Object.keys(o).forEach(k => { o[k] = round2(o[k]); }));
    return t;
  }

  /* ---------- Feature 3: audit flags (review prompts, never fraud labels) ---------- */
  function audit(rows, opts) {
    opts = opts || {};
    const threshold = Number(opts.threshold) || 0;
    const map = new Map();
    const flag = (r, type, text, step) => {
      if (!map.has(r._line)) map.set(r._line, { line: r._line, row: r, reasons: [] });
      map.get(r._line).reasons.push({ type, text, step });
    };
    const usable = rows.filter(r => r._amount > 0 && r._type);

    // 1) Unexpected amounts: much higher than the usual level for the same category (robust median/MAD test)
    const groups = {};
    usable.forEach(r => {
      const cat = String(r.category || '').trim().toLowerCase();
      if (!cat) return;
      (groups[r._type + '|' + cat] = groups[r._type + '|' + cat] || []).push(r);
    });
    Object.values(groups).forEach(g => {
      if (g.length < 4) return;
      const amts = g.map(r => r._amount);
      const med = median(amts);
      const mad = median(amts.map(a => Math.abs(a - med)));
      g.forEach(r => {
        const unusual = mad > 0 ? (0.6745 * (r._amount - med) / mad > 3.5) : (med > 0 && r._amount > med * 3);
        if (unusual) flag(r, 'Unexpected amount',
          'Much higher than the usual level for "' + r.category + '" (typical about ' + num(med) + ', this row ' + num(r._amount) + ').',
          'Ask for the invoice or approval and confirm the amount and category are correct.');
      });
    });

    // 2) Possible duplicate payments: same vendor + same amount within 7 days
    const pay = {};
    usable.filter(r => r._type === 'Expense' && r._date && String(r.vendor || '').trim()).forEach(r => {
      const k = r.vendor.trim().toLowerCase() + '|' + r._amount;
      (pay[k] = pay[k] || []).push(r);
    });
    Object.values(pay).forEach(g => {
      g.sort((a, b) => a._date - b._date);
      for (let i = 1; i < g.length; i++) {
        const days = Math.round((g[i]._date - g[i - 1]._date) / 86400000);
        if (days <= 7) {
          const when = days === 0 ? 'on the same day' : days + ' day(s) apart';
          flag(g[i], 'Possible duplicate payment', 'Same vendor and amount as Row ' + g[i - 1]._line + ', ' + when + '.', 'Check the bank statement and invoice to see whether it was paid twice or is two genuine invoices.');
          flag(g[i - 1], 'Possible duplicate payment', 'Same vendor and amount as Row ' + g[i]._line + ', ' + when + '.', 'Check the bank statement and invoice to see whether it was paid twice or is two genuine invoices.');
        }
      }
    });

    // 3) Amounts just under the approval limit
    if (threshold > 0) {
      usable.filter(r => r._type === 'Expense' && r._amount >= threshold * 0.9 && r._amount < threshold).forEach(r => {
        flag(r, 'Just below approval limit', 'Amount ' + num(r._amount) + ' is within 10% below the approval limit of ' + num(threshold) + '. This can be coincidence.', 'Confirm who approved it and whether a larger purchase was split into smaller ones.');
      });
    }

    const flags = [...map.values()].sort((a, b) => a.line - b.line);
    flags.forEach(f => { f.priority = f.reasons.length >= 2 ? 'Higher priority' : 'Review'; });
    return flags;
  }

  const api = { COLS, parseCSV, toRecords, parseAmount, parseDate, normType, analyze, totals, audit, round2, num };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.SmartCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
