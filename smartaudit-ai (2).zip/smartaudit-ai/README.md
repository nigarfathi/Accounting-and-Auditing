# SmartAudit AI – AI-Powered Accounting and Auditing Assistant

A working hackathon prototype built with plain **HTML, CSS and JavaScript**. No installation, no build step, no server needed.

> **Decision-support tool only.** It does not replace a qualified accountant or auditor. It cannot find every accounting error, and a flagged transaction is **never** proof of fraud – it is a prompt for a human to look.

---

## 1. Folder structure

```
smartaudit-ai/
├── index.html            Page shell (sidebar, content area)
├── styles.css            Dark blue / white / light blue theme, responsive layout
├── core.js               Pure logic: CSV parsing, error checks, totals, audit flags
├── sample-data.js        Fictional sample dataset (loaded when the site opens)
├── app.js                User interface: views, charts, buttons, settings, assistant
├── sample-data/
│   └── sample_transactions.csv   Same sample data as a file you can upload
└── README.md
```

## 2. How to run it

**Easiest way (works offline):**
1. Unzip the folder.
2. Double-click `index.html`. It opens in your browser (Chrome, Edge, Firefox or Safari).

**Optional – run through a local web server** (only if your browser blocks something):
1. Open a terminal inside the `smartaudit-ai` folder.
2. Run `python -m http.server 8000` (or `python3 ...`).
3. Open `http://localhost:8000` in your browser.

To test the logic without a browser (optional, needs Node.js): `node test/run-tests.js`

## 3. Sample data to test with

The site opens with **52 fictional records** (April–September 2026, in rupees). They include deliberate mistakes so the checkers have something to find. The same data is in `sample-data/sample_transactions.csv`, or click **Download sample CSV** on the Error Detection page.

What is planted in the sample (and what you should see):

| Planted problem | Where it is reported |
|---|---|
| Exact duplicate rent row (5 June) | Error Detection – *Duplicate entry*; Audit – *Possible duplicate payment* |
| 4 × 2,500 recorded as 12,000 | Error Detection – *Calculation mismatch* |
| Missing category (team lunch), missing description | Error Detection – *Missing value* |
| Amount written as `abc` | Error Detection – *Invalid amount* |
| Negative amount (−8,000) | Error Detection – *Negative amount* (left out of totals) |
| Date `2026-02-30` | Error Detection – *Invalid date* |
| Type `Refund` | Error Detection – *Invalid type* |
| ₹150,000 machinery purchase; ₹40,000 ad spend | Audit – *Unexpected amount* |
| Two ₹49,900 payments to Apex Supplies one day apart | Audit – *Possible duplicate payment* + *Just below approval limit* (limit ₹50,000) |

Expected headline numbers on the dashboard: income ₹8,07,800, expenses ₹7,94,100, net profit ₹13,700, 52 records checked, 8 potential errors, 6 items for human review.

You can also make your own CSV. Required columns: `date`, `type`, `amount`. Optional: `description`, `vendor`, `category`, `quantity`, `unit_price`. Dates as `YYYY-MM-DD` or `DD/MM/YYYY`. Type is `Income` or `Expense`.

## 4. How each feature works

**Financial Dashboard (home page).** Totals are plain sums: *income* = sum of positive amounts on Income rows, *expenses* = same for Expense rows, *net* = income − expenses. A "How these numbers are calculated" panel shows the exact formula with the row counts and a category breakdown, so anyone can verify it in a spreadsheet. Charts: income vs expenses by month (SVG bars) and top expense categories. Cards show records checked, potential errors and items for review.

**Financial Reports.** Enter income, expenses, assets and liabilities line by line (add or remove rows), or fill income and expenses from the loaded records. *Generate report* validates the entries (no blank names, no non-numeric or negative numbers), then shows an income and expense summary, net profit or loss, a simplified asset/liability/equity position, and a plain-English summary. The summary is **rule-based, not AI**, and is labelled so. Print / save as PDF is built in.

**Error Detection.** Upload a CSV, paste CSV text, or add a record by hand. Each row is checked for: missing values, invalid dates, invalid types, invalid/negative/zero amounts, quantity × unit price ≠ amount, and exact duplicates. Every problem has a plain-English explanation and a suggested fix. You can filter errors vs warnings, download the issue list, and delete rows from the loaded copy (your original file is never changed).

**Audit Assistant.** Three transparent checks on the loaded transactions: (1) *unexpected amount* – far above the usual level for the same category (median / MAD statistic); (2) *possible duplicate payment* – same vendor and amount within 7 days; (3) *just below approval limit* – within 10% under the limit set in Settings. Results are worded as "needs human review", with a suggested next step, a Reviewed checkbox and a download. Nothing is called fraud.

**Ask Assistant (AI Explanation Assistant).** A question box with example chips. In the default **Demo mode** (clearly labelled on screen and on every answer), replies come from a built-in glossary of about 25 accounting topics and error-fix tips, plus a summary of your loaded data. It is not AI and does not pretend to be. If you add your own API key and tick the consent box in Settings, questions go to a real model (see section 6).

**Settings.** Currency symbol, approval limit, whether exact duplicates are excluded from totals, optional AI connection, and a reset button.

## 5. Safety and privacy choices built in

- All parsing and analysis run **in your browser**. Files are not uploaded anywhere.
- Nothing is sent to an external service unless you tick the consent box *and* enter an API key. Even then only your typed question (and, if you tick a second box, aggregate totals) is sent – never individual records.
- The API key is kept in memory only; it is not saved and disappears on refresh.
- The sample dataset is entirely fictional.
- Disclaimers appear in the sidebar, footer and report. The tool never claims to find every error or to prove fraud.
- All text from CSV files is HTML-escaped before display.

**Known limits (be honest with the judges):** the checks only see the columns in the file; the audit statistics need at least 4 records per category; the DD/MM/YYYY vs MM/DD/YYYY ambiguity is resolved as day-first; it is a prototype, not audited accounting software.

## 6. Demonstration workflow for hackathon judges (about 5 minutes)

1. **Problem (30 s).** "Small businesses lose time and money to bookkeeping mistakes that are caught late."
2. **Dashboard (45 s).** Open the site. It loads fictional sample data. Point to income, expenses, net profit, the monthly chart, and 8 potential errors. Open *How these numbers are calculated* to show the maths is transparent.
3. **Error Detection (90 s).** Show the issue table: duplicate rent, calculation mismatch (4 × 2,500 ≠ 12,000), `abc` amount, 30 February. Read one "What it means / Suggested fix". Then add a manual record with a blank date and amount `12x` and show the instant warning toast. Optionally download the sample CSV and upload it to show the upload path.
4. **Audit Assistant (60 s).** Show the flagged ₹150,000 purchase and the two ₹49,900 payments. Stress the yellow banner: "These are prompts for human review, not fraud accusations." Tick *Reviewed* on one item.
5. **Financial Reports (45 s).** Click *Fill income & expenses from loaded records*, then *Generate report*. Show net result, equity and the rule-based summary label.
6. **Ask Assistant (30 s).** Click "Explain debit and credit". Point to the **DEMO MODE** tag: honest about not being AI. Mention that a real model plugs in via Settings.
7. **Close (30 s).** Privacy (data stays in the browser), limits, and the roadmap in section 7.

Questions judges may ask: *Is it really AI?* – Detection uses statistics and rules; the explanation assistant is a labelled demo unless an API key is added. *Can it be trusted?* – It shows its formulas, never labels fraud, and always defers to a human.

## 7. Adding a real AI model or API later

1. **Use a small backend, not the browser, for the key.** Create a tiny server (Node/Express or Python/FastAPI) with one endpoint, e.g. `POST /api/explain`. The server holds the API key in an environment variable, forwards the question to the model, and returns the text. Point `askAI()` in `app.js` at your endpoint instead of calling the vendor directly.
2. **Prompt design.** Use a system prompt such as: *"You explain accounting to beginners in simple English. You support decisions but do not replace a qualified accountant. Never say a transaction is fraud; say it needs human review."* Send only what is needed (a question, or aggregate numbers), and strip names and account numbers.
3. **Explain findings with AI.** After the rule-based checks run, send each finding (type, amount, category – not the vendor name) and ask the model for a plain-English explanation and next steps. Keep the numbers coming from your code, not from the model.
4. **Smarter detection.** Replace or supplement the median/MAD check with an Isolation Forest or seasonal baselines; add Benford's-law digit analysis for large datasets; compare against budgets and prior periods.
5. **Read documents.** Add invoice/receipt OCR (e.g. a vision-capable model) so users can upload a PDF or photo and have fields extracted, then run the same error checks.
6. **Integrations and quality.** Import from Tally, Zoho Books or bank CSVs; add user accounts and encrypted storage; add automated tests, an audit log of who reviewed what, and a human sign-off step.
7. **Evaluate before trusting.** Build a test set of known-error records, measure false positives and misses, and report those numbers honestly.

## 8. Troubleshooting

- *Upload says "Missing required column(s)"* – your file needs `date`, `amount` and `type` headers (aliases such as `qty`, `price`, `supplier` are recognised for optional columns).
- *Excel file?* – In Excel use **Save As → CSV (Comma delimited)**.
- *Charts empty* – rows need valid dates and positive amounts to be charted.
- *Live AI fails* – check the key, consent box and model name in Settings; the assistant falls back to the demo answer and shows an error message.
