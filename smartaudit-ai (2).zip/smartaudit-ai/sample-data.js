/* Fictional sample data. No real people, companies or customers. Contains deliberate mistakes so the checkers have something to find. */
globalThis.SAMPLE_CSV = `date,description,vendor,category,type,quantity,unit_price,amount
2026-04-02,Product sales invoice 1001,Greenfield Traders,Sales,Income,25,4500,112500
2026-04-10,Consulting service,Bluebird Retail,Services,Income,,,32000
2026-04-05,Office rent April,Sunrise Properties,Rent,Expense,,,20000
2026-04-30,Staff salaries April,Payroll,Salaries,Expense,,,35000
2026-04-12,Electricity bill,City Power Board,Utilities,Expense,,,6200
2026-04-18,Printer paper,Paper Hub,Office Supplies,Expense,20,350,7000
2026-04-22,Social media ads,AdVista,Marketing,Expense,,,12000
2026-05-03,Product sales invoice 1002,Greenfield Traders,Sales,Income,22,4500,99000
2026-05-14,Consulting service,Orchid Foods,Services,Income,,,28000
2026-05-05,Office rent May,Sunrise Properties,Rent,Expense,,,20000
2026-05-31,Staff salaries May,Payroll,Salaries,Expense,,,35000
2026-05-11,Electricity bill,City Power Board,Utilities,Expense,,,6500
2026-05-20,Accounting software,LedgerSoft,Software,Expense,,,4800
2026-05-25,Client visit travel,Rail Express,Travel,Expense,,,5400
2026-06-02,Product sales invoice 1003,Greenfield Traders,Sales,Income,18,4500,81000
2026-06-09,Product sales invoice 1004,Maple Stores,Sales,Income,15,4200,63000
2026-06-05,Office rent June,Sunrise Properties,Rent,Expense,,,20000
2026-06-05,Office rent June,Sunrise Properties,Rent,Expense,,,20000
2026-06-30,Staff salaries June,Payroll,Salaries,Expense,,,35000
2026-06-12,Electricity bill,City Power Board,Utilities,Expense,,,7100
2026-06-18,Marketing campaign,AdVista,Marketing,Expense,,,14000
2026-06-21,Office chairs,Furniture Mart,Office Supplies,Expense,6,3800,22800
2026-07-03,Product sales invoice 1005,Greenfield Traders,Sales,Income,21,4500,94500
2026-07-15,Consulting service,Bluebird Retail,Services,Income,,,35000
2026-07-05,Office rent July,Sunrise Properties,Rent,Expense,,,20000
2026-07-31,Staff salaries July,Payroll,Salaries,Expense,,,35000
2026-07-10,Electricity bill,City Power Board,Utilities,Expense,,,6900
2026-07-17,Printer toner,Paper Hub,Office Supplies,Expense,4,2500,12000
2026-07-24,Team lunch,Food Court,,Expense,,,3200
2026-08-04,Product sales invoice 1006,Maple Stores,Sales,Income,24,4200,100800
2026-08-13,Consulting service,Orchid Foods,Services,Income,,,30000
2026-08-05,Office rent August,Sunrise Properties,Rent,Expense,,,20000
2026-08-31,Staff salaries August,Payroll,Salaries,Expense,,,35000
2026-08-11,Electricity bill,City Power Board,Utilities,Expense,,,7300
2026-08-19,Server hosting,CloudNest,Software,Expense,,,5200
2026-08-21,Conference travel,Rail Express,Travel,Expense,,,6100
2026-08-24,Festival promotion,AdVista,Marketing,Expense,,,13000
2026-08-27,Machinery purchase,Delta Machines,Office Supplies,Expense,,,150000
2026-08-29,Customer refund,Maple Stores,Sales,Refund,,,2000
2026-09-02,Product sales invoice 1007,Greenfield Traders,Sales,Income,22,4500,99000
2026-09-14,Consulting service,Bluebird Retail,Services,Income,,,33000
2026-09-05,Office rent September,Sunrise Properties,Rent,Expense,,,20000
2026-09-30,Staff salaries September,Payroll,Salaries,Expense,,,35000
2026-09-10,Electricity bill,City Power Board,Utilities,Expense,,,7000
2026-09-12,Stationery,Paper Hub,Office Supplies,Expense,,,4500
2026-09-15,Vendor payment,Apex Supplies,Office Supplies,Expense,,,49900
2026-09-16,Vendor payment,Apex Supplies,Office Supplies,Expense,,,49900
2026-09-20,Marketing campaign,AdVista,Marketing,Expense,,,-8000
2026-09-22,Consulting service,Orchid Foods,Services,Income,,,abc
2026-09-25,Social media ads,AdVista,Marketing,Expense,,,40000
2026-09-27,,Quick Print,Office Supplies,Expense,,,1500
2026-02-30,Courier charges,QuickShip,Other,Expense,,,1800
`;
